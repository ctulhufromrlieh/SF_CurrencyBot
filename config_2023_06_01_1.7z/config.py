# API key from
# https://www.cryptocompare.com/
cryptocompare_key = "2fa1823f06f652ccadb7872e3b562eac6964df742cc84810c28fb83f4a7f27f6"

# ubuntu:
# sudo service redis-server start
# redis parameters
redis_host = "127.0.0.1"
redis_port = 6379
redis_psw = ""

# caching time (in seconds)
caching_time = 5 * 60

# Telegram bot token
telegram_bot_token = "5994320025:AAErGlKvuiy4GHbrn25F7s4LAh4WSRSpe-c"

